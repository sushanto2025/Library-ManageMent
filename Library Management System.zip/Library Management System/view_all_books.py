def view_all_books(all_books):
    import csv
    all_books = []
    space = " "
    print(f"Seriol No{space:<2}Title{space:<18}Author{space:<18}ISBN{space:<5}Year{space:<3}Price{space:<3}Quantity")
    print("===========================================================================================")
    with open('all_books.csv', 'r') as file:
        myfile = csv.reader(file)
        i = 1
        for row in myfile:
            all_books.append(row)
            if all_books != []:
                print(f"{i:<11}{row[0]:<22}{row[1]:<25}{row[2]:<8}{row[3]:<8}{row[4]:<8}{row[5]}")
                i += 1
                # print(f"{int(i)+1}.\t\t{all_books[i][0]}\t\t{all_books[i][1]}\t\t{all_books[i][2]}\t\t{all_books[i][3]}\t\t{all_books[i][4]}\t\t{all_books[i][5]}")Year: {book['year']} | Price: {book['price']} | Quantity: {book['quantity']}")

            else:
                print("No Book found in program")
                print("")
        print("--------------------------------------------------------------------------------------------")
