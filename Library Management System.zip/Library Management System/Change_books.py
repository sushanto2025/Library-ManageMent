def change_books():
    import csv
    all_books = []
    Heading = ['Title', 'Author', 'ISBN', 'Year', 'Price', 'Quantity']
    with open('all_books.csv', 'r') as file:
        myfile = csv.reader(file)
        for row in myfile:
            all_books.append(row)

        edit_record = int(input("\nEnter the Record You Want to Edit =>Serial No. (1-" + str(len(all_books)) + ") : "))

        for i in range(len(all_books[0])):
            newDatails = input(f"Enter {Heading[i]} : ")
            all_books[edit_record - 1][i] = newDatails

        print("\nHere is the Line Going to be Changed bellow:".title())
        print("**********************************************")
        for i in range(len(all_books)):
            print("Row No " + str(i) + ":" + str(all_books[i]))
        yn = input("Are you sure (Y/N : )".lower())
        if yn == "y":
            with open("all_books.csv", "w+") as myfile:
                change_file = csv.writer(myfile)
                for i in range(len(all_books)):
                    change_file.writerow(all_books[i])
        elif yn == "n":
            print("Ok, No problem")
        else:
            print("Wrong input, Try Again (Y/N")