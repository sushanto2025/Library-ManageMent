def save_all_books(all_books):
    import csv
    with open("all_books.csv", "w+") as fp:
        change_file = csv.writer(fp)
        for book in all_books:
            line = f"{book[0]}, {book[1]}, {book[2]}, {book[3]}, {book[4]}\n"
            change_file.writerow(line)
